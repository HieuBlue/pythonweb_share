﻿/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","uk",{title:"Налаштування Заповнювача",toolbar:"Створити Заповнювач",name:"Назва заповнювача",invalidName:"Заповнювач не може бути порожнім і не може містити наступні символи: [, ], \x3c, \x3e",pathName:"заповнювач"});