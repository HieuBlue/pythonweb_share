﻿/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","ku",{title:"هەڵگری ڕەنگ بۆ ڕووکاری بەکارهێنەر",options:"هه‌ڵبژارده‌ی ڕه‌نگه‌کان",highlight:"نیشانکردن",selected:"هەڵبژاردنی ڕەنگ",predefined:"کۆمەڵە ڕەنگە دیاریکراوەکانی پێشوو",config:"ئەم دەقانە بلکێنە بە پەڕگەی config.js-fil"});